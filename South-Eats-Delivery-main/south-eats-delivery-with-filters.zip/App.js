import React, { useState } from 'react';
import RootNavigation from "./navigation";
import { auth } from './config/firebase';

export default function App() {
  const [isLogged, setIsLoggedIn] = useState(false);
  auth.onAuthStateChanged((user) => {
    if (user != null) {
      setIsLoggedIn(true)
    }
    else {
      setIsLoggedIn(false)
    }
  });

  return (
    <RootNavigation />
  );
}

