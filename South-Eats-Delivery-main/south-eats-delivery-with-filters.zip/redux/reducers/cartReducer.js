let defaultState = {
  selectedItems: { items: [], restaurant: "", name: "", street: "", apartment: "", floor: "", city: "", phone: "" },
};

let cartReducer = (state = defaultState, action) => {
  switch (action.type) {
    case "ADD_TO_CART": {
      let newState = { ...state };

      if (action.payload.checkboxValue) {
        console.log("ADD TO CART");

        newState.selectedItems = {
          items: [...newState.selectedItems.items, action.payload],
          restaurant: action.payload.restaurant,
          name: action.payload.name,
          street: action.payload.street,
          apartment: action.payload.apartment,
          floor: action.payload.floor,
          city: action.payload.city,
          phone: action.payload.phone,

        };
      } else {
        console.log("REMOVE FROM CART");
        newState.selectedItems = {
          items: [
            ...newState.selectedItems.items.filter(
              (item) => item.title !== action.payload.title
            ),
          ],
          restaurant: action.payload.restaurant,

        };
      }
      console.log(newState, "👉");
      return newState;
    }

    default:
      return state;
  }
};

export default cartReducer;