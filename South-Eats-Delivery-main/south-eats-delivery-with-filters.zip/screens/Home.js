import React, { useEffect, useState } from 'react';
import { View, Text, SafeAreaView, TouchableOpacity, Pressable, FlatList, StyleSheet, TextInput, Dimensions, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import AddCourier from './AddCourier';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from "react-redux";
import { db, auth } from '../config/firebase';
import OrderItem from '../components/OrderItem';

const vh = Dimensions.get('window').height * 0.01;


export default function Home() {
    const [todos, setTodos] = useState([]);
    const [addData, setAddData] = useState('');
    const [filterText, setFilterText] = useState('');
    const navigation = useNavigation();
    const [loading, setLoading] = useState(false);
    const { items, restaurant, name, street, apartment, floor, city, phone } = useSelector((state) => state.cartReducer.selectedItems);
    const currentUser = auth.currentUser;
    const [user, setUser] = useState(null) // This user
    const [users, setUsers] = useState([]) // Other users
    const [orders, setOrders] = useState([])

    // useEffect(()=>{
    //     db.collection("users").doc(auth().currentUser.uid).get()
    //     .then(user =>{
    //         setUser(user.data())
    //     })
    // }, [])


    // useEffect(() => {
    //     if(user)
    //         db.collection("users").where("role", "==",(user?.role === "Courier" ? "Restaurant": "Courier"))
    //         .onSnapshot(users =>{
    //             if(!users.empty){
    //                 const USERS =[]

    //                 users.forEach(user => {
    //                     USERS.push(user.data())
    //                 })
    //                 setUsers(USERS)
    //             }
    //         })
    // },[user])

    // const [users, setUsers] = useState([]);


    const usersTable = db.collection('users');
    // get all the data from collection orders
    useEffect(() => {
        db.collection('orders')
            .where("status", "==", "pending")
            .onSnapshot(
                querySnapshot => {
                    const orders = []
                    querySnapshot.forEach((doc) => {
                        const { createdAt, items, restaurantName, name, street, apartment, floor, city, phone } = doc.data()
                        orders.push({
                            id: doc.id,
                            createdAt,
                            items,
                            restaurantName,
                            name,
                            street,
                            apartment,
                            floor,
                            city,
                            phone

                        })
                    })

                    setOrders(orders)
                }
            )
    }, [])
    useEffect(() => {
        usersTable
            .onSnapshot(
                querySnapshot => {
                    const users = []
                    querySnapshot.forEach((doc) => {
                        const { email, name, role } = doc.data()
                        users.push({
                            id: doc.id,
                            email,
                            name,
                            role
                        })
                    })
                    setUsers(users)
                }
            )
    }, [])

    const dispatch = useDispatch();
    const selectItem = (name) =>
        dispatch({
            type: "ADD_TO_CART",
            payload: {
                restaurant: orders,
                name: name,
                street: street,
                apartment: apartment,
                floor: floor,
                city: city,
                phone: phone,

            },
        });

    const handleOnStartDelivery = async (docId) => {
        try {
            await db.collection("orders").doc(docId).update({
                status: "inprogress"
            });

            Alert.alert("Order delivery has been started");
        } catch (error) {
            console.log(error);
            Alert.alert(error?.message);
        }
    }

    const renderItem = ({ item }) => {
        return (
            <OrderItem
                item={item}
                buttonTitle="Start Delivery"
                buttonStyle={styles.buttonStyle}
                onPress={handleOnStartDelivery}
            />
        )
    }

    return (
        <SafeAreaView style={{ backgroundColor: "#eee", flex: 1 }}>
            <View>
                <Text style={{
                    fontSize: 15,
                    fontWeight: "900",
                    alignSelf: 'center'
                }}>Orders</Text>

                <View style={styles.filterContainer}>
                    <Text style={styles.filterTitle}>Filter by Restaurant Name</Text>
                    <TextInput
                        value={filterText}
                        placeholder='Restaurant Name'
                        style={styles.filterInput}
                        onChangeText={setFilterText}
                    />
                </View>

                <View style={styles.listContainer}>
                    <FlatList
                        style={{ height: vh * 88 }}
                        data={orders.filter((order => order.restaurantName.toLowerCase().includes(filterText.toLowerCase())))}
                        renderItem={renderItem}
                    />
                    <TouchableOpacity
                        style={{
                            height: 50,
                            marginTop: 10,
                            alignItems: 'center',
                            justifyContent: 'center',
                            backgroundColor: '#75C568',
                        }}
                        onPress={() => navigation.navigate("DeliveredOrders")}>
                        <Text style={{
                            fontSize: 16,
                            fontWeight: "500"
                        }}>Let's Start</Text>
                    </TouchableOpacity>
                </View>

                {/* <TouchableOpacity 
            style={{
                backgroundColor: 'orange',
                paddingVertical: 10,
                paddingHorizontal: 16,
                marginHorizontal:10,
                borderRadius: 30,
               }}  
            onPress={()=>navigation.navigate("AddCourier")}>
                <Text style={{
                    fontSize:15, 
                    fontWeight:"900"
                }}>Add new courier</Text>
            </TouchableOpacity> */}
            </View>
        </SafeAreaView>

    )
}
// }


const styles = StyleSheet.create({
    container: {
        backgroundColor: '#e5e5e5',
        padding: 15,
        broderRadius: 15,
        margin: 5,
        marginHorizontal: 10,
    },
    innerContainer: {
        alignItems: 'center',
        flexDirection: 'column',
    },
    itemHeading: {
        fontWeight: 'bold'
    },
    itemText: {
        fontWeight: '300'
    },
    buttonStyle: {
        backgroundColor: '#ECC846',
    },
    filterContainer: {
        backgroundColor: '#e5e5e5',
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 12,
        paddingVertical: 12,
        marginHorizontal: 10,
        borderRadius: 5
    },
    filterTitle: {
        width: "90%",
        marginBottom: 10
    },
    filterInput: {
        height: 35,
        width: "90%",
        borderWidth: 1,
        borderRadius: 8,
        backgroundColor: "white",
        textAlignVertical: 'center',
        paddingHorizontal: 10
    },
    listContainer: {
        height: vh * 80,
    }
})