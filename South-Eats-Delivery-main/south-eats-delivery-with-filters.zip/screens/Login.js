import { View, Text, SafeAreaView, TextInput} from 'react-native';
import { useState } from 'react';
import React from 'react';
import firebase from 'firebase';
import { TouchableOpacity } from 'react-native-gesture-handler';
import styles from "../assets/Style";


export default function Login({navigation}) {

    const [values,setValues] = useState({
        email: "",
        pwd: ""
    })

    function handleChanges(text, eventName){
        setValues(prev =>{
            return {
                ...prev,
                [eventName]: text
            }
        })

    }

    function Login(){

        const {email,pwd} = values

        firebase.auth().signInWithEmailAndPassword(email,pwd)
            .then(()=>{
                navigation.navigate("Home")
    
            })
            .catch((error)=>{
                alert(error.message)
            })

    }

  return (
    <SafeAreaView style={{ backgroundColor:"#eee", flex:1}}>
        
        <View style={{
                margin:5,
                justifyContent: 'center',
                height: "100%"
            }}>
            <Text style={{
                fontSize:20,
                fontWeight: "bold"}}>Login</Text>
        
        <TextInput 
            style={styles.formInputContainer} 
            placeholder="Email Address" 
            onChangeText={text=>handleChanges(text,"email")}
        />
        <TextInput 
            style={styles.formInputContainer} 
            placeholder="Password" 
            onChangeText={text=>handleChanges(text,"pwd")} 
            secureTextEntry={true}
        />
        <View style={{flexDirection:"row", alignSelf:"center", marginTop:10}}>
            <TouchableOpacity 
            style={{
                backgroundColor: 'orange',
                paddingVertical: 10,
                paddingHorizontal: 16,
                marginHorizontal:10,
                borderRadius: 30,
               }}  
            onPress={()=>Login()}>
                <Text style={{
                    fontSize:15, 
                    fontWeight:"900"
                }}>Login</Text>
            </TouchableOpacity>
            <TouchableOpacity 
            style={{
                backgroundColor: 'orange',
                paddingVertical: 10,
                paddingHorizontal: 16,
                marginHorizontal:10,
                borderRadius: 30,
               }}  
               onPress={()=>navigation.navigate("Home")}>
                <Text style={{
                    fontSize:15, 
                    fontWeight:"900"
                }}>Sign Up</Text>
            </TouchableOpacity>
        </View>
        </View>
    </SafeAreaView>
  );
}