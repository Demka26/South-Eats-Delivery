import React from 'react';
import { View, Text } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import Home from "./screens/Home";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import AddCourier from './screens/AddCourier';
import Login from './screens/Login';
import { Provider as ReduxProvider } from 'react-redux';
import configureStore from "./redux/store";
import DeliveredOrders from './screens/DeliveredOrders';

const store = configureStore();

export default function RootNavigation() {

  const Tab = createBottomTabNavigator();
  const Stack = createStackNavigator();

  const screenOptions = {
    headerShown: false,
  }
  // function HomeTabs() {
  //     return (
  //         <Tab.Navigator>
  //         <Tab.Screen 
  //         name="Home" 
  //         component={Home}
  //         options={{
  //             tabBarIcon: ({size, color}) => (<Icon name="home" color={color} size={size} />)
  //         }} />
  //         <Tab.Screen 
  //         name="Add courier" 
  //         component={AddCourier} 
  //         options={{
  //             tabBarIcon: ({size, color}) => (<Icon name="plus" color={color} size={size} />)
  //         }}
  //         />

  //     </Tab.Navigator>
  //     );
  //   }
  return (
    <ReduxProvider store={store}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName='Home' screenOptions={screenOptions}>
          <Stack.Screen name='Login' component={Login} />
          <Stack.Screen name='Home' component={Home} />
          <Stack.Screen name='AddCourier' component={AddCourier} />
          <Stack.Screen name='DeliveredOrders' component={DeliveredOrders} />
        </Stack.Navigator>
      </NavigationContainer>
    </ReduxProvider>



  )
}