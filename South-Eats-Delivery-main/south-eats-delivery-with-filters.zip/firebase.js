import firebase from "firebase/app";
import { useState } from "react";
import "firebase/auth";





export default firebase;